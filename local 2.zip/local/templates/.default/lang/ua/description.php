<?
$MESS["T_DEFAULT_DESC_NAME"] = "Спільний шаблон";
$MESS["T_DEFAULT_DESC_DESC"] = "Спільні файли, що включаються, header.php та footer.php за умовчанням.";
?>