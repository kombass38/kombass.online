<?
$MESS ['T_DEFAULT_DESC_NAME'] = "Common template";
$MESS ['T_DEFAULT_DESC_DESC'] = "Common include files (header.php and footer.php by default).";
?>