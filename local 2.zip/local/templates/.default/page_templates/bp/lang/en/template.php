<?
$MESS ['bp_wizard_name'] = "Business Process";
$MESS ['bp_wizard_title'] = "Business Process Section (SEF)";
$MESS ['bp_wizard_settings'] = "Business Process Parameters";
$MESS ['bp_wizard_lib_name'] = "Business Process Name:";
$MESS ['bp_wizard_lib_name_val'] = "Process";
$MESS ['bp_wizard_iblock_type'] = "Information Block Type:";
$MESS ['bp_wizard_iblock'] = "Documents Information Block:";
$MESS ['bp_wizard_iblock_new'] = "Create New Information Block Type With ID";
$MESS ['bp_wizard_iblock_select'] = "Select Existing Information Block Type:";
?>