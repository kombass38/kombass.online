<?
$MESS ['TP_BC_PRODUCT_QUANTITY_VARIABLE'] = "Product Quantity Parameter Name";
$MESS ['TP_BC_PRODUCT_PROPS_VARIABLE'] = "Product Properties Parameter Name";
$MESS ['TP_BC_USE_PRODUCT_QUANTITY'] = "Enable Product Quantity Field";
$MESS ['TP_BC_PRODUCT_PROPERTIES'] = "Product Properties";
?>