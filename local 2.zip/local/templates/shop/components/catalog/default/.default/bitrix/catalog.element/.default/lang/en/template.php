<?
$MESS["CATALOG_ADD_TO_BASKET"] = "Add to cart";
$MESS["CATALOG_MORE_PHOTO"] = "More photo";
$MESS["CATALOG_DOWNLOAD"] = "Download";
$MESS["CATALOG_BACK"] = "Back to the section";
$MESS["CATALOG_BUY"] = "Buy";
$MESS["CATALOG_NOT_AVAILABLE"] = "(not available from stock)";
$MESS["CATALOG_QUANTITY"] = "Quantity";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "from #FROM# to #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "#FROM# and more";
$MESS["CATALOG_QUANTITY_TO"] = "up to #TO#";
$MESS["CATALOG_PRICE_VAT"] = "tax included";
$MESS["CATALOG_PRICE_NOVAT"] = "tax excluded";
$MESS["CATALOG_VAT"] = "Tax rate";
$MESS["CATALOG_NO_VAT"] = "not taxed";
$MESS["CATALOG_VAT_INCLUDED"] = "Tax rate included in price";
$MESS["CATALOG_VAT_NOT_INCLUDED"] = "Tax rate not included in price";
$MESS["CT_BCE_QUANTITY"] = "Quantity";
$MESS["CT_BCE_CATALOG_ADD"] = "Add to cart";
$MESS["CT_BCE_CATALOG_COMPARE"] = "Compare";
?>