<?
$arTemplate = array (
  'NAME' => 'Shop',
  'DESCRIPTION' => 'shop KOM',
  'SORT' => '',
  'TYPE' => '',
);
?>